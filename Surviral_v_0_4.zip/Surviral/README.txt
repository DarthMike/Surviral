

**********CONTROLS**********:

************************************************************************************

This software is copyright Miguel Angel Qui�ones Garc�a. It is a
free game and not intended for any commercial purposes.
It uses audio from other sources, freely available for non commercial
use (see corresponding file).

